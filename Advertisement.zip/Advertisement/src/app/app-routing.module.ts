import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdvertaisementFormComponentComponent } from './advertaisement-form-component/advertaisement-form-component.component';

const routes: Routes = [
  { path:'Form', component: AdvertaisementFormComponentComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
