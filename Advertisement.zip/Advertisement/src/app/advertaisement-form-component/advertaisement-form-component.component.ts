import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-advertaisement-form-component',
  templateUrl: './advertaisement-form-component.component.html',
  styleUrls: ['./advertaisement-form-component.component.css']
})
export class AdvertaisementFormComponentComponent implements OnInit {

  categories = ['Furniture', 'Hardware', 'Mobile']
  constructor() { }

  ngOnInit(): void {
  }

}
