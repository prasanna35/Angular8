import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdvertaisementFormComponentComponent } from './advertaisement-form-component.component';

describe('AdvertaisementFormComponentComponent', () => {
  let component: AdvertaisementFormComponentComponent;
  let fixture: ComponentFixture<AdvertaisementFormComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdvertaisementFormComponentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdvertaisementFormComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
